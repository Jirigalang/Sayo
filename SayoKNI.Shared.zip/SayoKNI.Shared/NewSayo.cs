﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using SayoKNI.SayoSegment;
using System.Linq;
using NewSprite = RenderingLibrary.Graphics.Sprite;
namespace SayoKNI;
internal class NewSayo
{
    private Segment[] _sayoBodys;
    private NewSprite _food;
    private Sayo.Core.Object.Grid _grid;
    private int _bodyCount = 3;
    public int Speed = 1;

    public SayoHead Head => (SayoHead)_sayoBodys[0];
    public SayoBody[] Body => [.. (SayoBody[])_sayoBodys.Skip(1)];

    public NewSayo()
    {

    }

    public void Load(SayoHead sayoHead, SayoBody sayoBody, SayoBody sayoButt, Sayo.Core.Object.Grid grid)
    {
        _sayoBodys[0] = sayoHead;
        _sayoBodys[1] = sayoBody;
        _sayoBodys[2] = sayoButt;

        _grid = grid;
    }

    public void Update(GameTime gameTime, Keys lastKey)
    {
        ((SayoHead)_sayoBodys[0]).UpdateLocation(lastKey, gameTime, Speed);
        for (int i = 1; i < _bodyCount; i++)
        {
            ((SayoBody)_sayoBodys[i]).UpdateLocation(_sayoBodys[i - 1], gameTime, Speed);
        }
        for(int i = 1; i < _bodyCount; i++)
        {
            ((SayoBody)_sayoBodys[i]).UpdateDirection(_sayoBodys[i - 1]);
        }
    }
}