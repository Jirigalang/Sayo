﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Sayo.Core.Scene;
using System;
using System.Collections.Generic;

namespace Sayo.Core
{
    public static class SceneManager
    {
        private static GraphicsDevice GraphicsDevice;
        private static ContentManager Content;
        private static GraphicsDeviceManager GraphicsDeviceManager;
        private static Dictionary<string, SceneBase> _scenes;
        private static SceneBase _sceneBuffer;
        public static RenderTarget2D BackGround { get; set; }
        public static SceneBase CurrentScene { get; set; }
        public static void Initialize(GraphicsDevice graphicsDevice, ContentManager content, GraphicsDeviceManager graphicsDeviceManager)
        {
            GraphicsDevice = graphicsDevice;
            Content = content;
            GraphicsDeviceManager = graphicsDeviceManager;
            _scenes = new Dictionary<string, SceneBase>
            {
                { "MainMenu", new MainMenuScene(GraphicsDevice, Content, GraphicsDeviceManager) },
                { "Game", new GameScene(GraphicsDevice, Content, GraphicsDeviceManager) },
                { "GameOver", new GameOverScene(GraphicsDevice, Content, GraphicsDeviceManager) },
                { "Credits", new CreditsScene(GraphicsDevice, Content, GraphicsDeviceManager) },
                { "Setting", new SettingScene(GraphicsDevice, Content, GraphicsDeviceManager) }
            };
        }

        public static void ChangeScene(string sceneName)
        {
            if (_scenes.TryGetValue(sceneName, out SceneBase scene))
            {
                CurrentScene?.Unload();
                CurrentScene = scene;
                CurrentScene.Load();
            }
            else
            {
                throw new Exception($"Scene '{sceneName}' not found.");
            }
        }

        public static void AddSubScene(string sceneName)
        {
            if (_scenes.TryGetValue(sceneName, out SceneBase value))
            {
                _sceneBuffer = CurrentScene;
                CurrentScene = value;
                CurrentScene.Load();
            }
            else
            {
                throw new Exception($"Scene '{sceneName}' not found.");
            }
        }

        public static void RemoveSubScene()
        {
            CurrentScene?.Unload();
            CurrentScene = _sceneBuffer;
            _sceneBuffer = null;
        }
    }
}
