﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace SayoKNI
{
    public class SpriteSheet
    {
        public Texture2D Texture { get; set; }
        public Rectangle[] Frames { get; set; }
        private List<FrameSheet> frameSheet;

        public SpriteSheet(ContentManager content, string TextureName)
        {
            Texture = content.Load<Texture2D>(TextureName);
            var json = content.Load<string>(TextureName);
            frameSheet = JsonSerializer.Deserialize(json, FrameSheetJsonContext.Default.ListFrameSheet);
            for (int i = 0; i < frameSheet.Count; i++)
            {
                var frame = frameSheet[i];
                frameSheet[i] = new FrameSheet(frame.Name, frame.X, frame.Y, frame.Width, frame.Height);
                Frames[i] = new Rectangle(frame.X, frame.Y, frame.Width, frame.Height);
            }
        }
    }
    public record FrameSheet(string Name, int X, int Y, int Width, int Height);
    [JsonSerializable(typeof(List<FrameSheet>))]
    public partial class FrameSheetJsonContext : JsonSerializerContext { }
}