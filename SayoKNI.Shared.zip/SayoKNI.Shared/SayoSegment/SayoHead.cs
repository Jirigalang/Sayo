﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sayo.Core.Object;

namespace SayoKNI.SayoSegment;
internal class SayoHead : Segment
{
    Rectangle Eating;
    Rectangle Normal;
    public SayoHead(Texture2D texture, Rectangle eating, Rectangle normal) : base(texture)
    {
        Location = new Point(2, 1);
        Eating = eating;
        Normal = normal;
    }
    public void UpdateLocation(Keys lastKey, GameTime gameTime, int speed)
    {
        Sprite.X = Direction switch
        {
            Keys.Up => Location.X,
            Keys.Down => Location.X,
            Keys.Left => Location.X - speed * gameTime.ElapsedGameTime.Seconds,
            Keys.Right => Location.X + speed * gameTime.ElapsedGameTime.Seconds,
            _ => Location.X
        };
        Sprite.Y = Direction switch
        {
            Keys.Up => Location.Y - speed * gameTime.ElapsedGameTime.Seconds,
            Keys.Down => Location.Y + speed * gameTime.ElapsedGameTime.Seconds,
            Keys.Left => Location.Y,
            Keys.Right => Location.Y,
            _ => Location.Y
        };
        if (Sprite.X % 100 != 0 && Sprite.Y % 100 != 0) return;
        Direction = lastKey;
        Location = new Point((int)Sprite.X / 100, (int)Sprite.Y / 100);
    }
    public void SetEatingState(Food food)
    {
        Sprite.SourceRectangle = food.Location == Location ? Eating : Normal;
    }
}