﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using RenderingLibrary;
using NewSprite = RenderingLibrary.Graphics.Sprite;

namespace SayoKNI.SayoSegment;
public abstract class Segment
{
    public NewSprite Sprite { get; set; }
    public Point Location = new(1,1);
    public Keys Direction = Keys.Right;
    public Segment(Texture2D texture)
    {
        Sprite.Texture = texture;
    }
}