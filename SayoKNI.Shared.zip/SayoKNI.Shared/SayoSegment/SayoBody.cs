﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace SayoKNI.SayoSegment;
internal class SayoBody : Segment
{
    public Rectangle Common { get; set; }
    public Rectangle Turned { get; set; }
    public SayoBody(Texture2D texture) : base(texture)
    {

    }

    public void UpdateLocation(Segment lastSegment,GameTime gameTime, int speed)
    {
        Sprite.X = lastSegment.Direction switch 
        {
            Keys.Up => Sprite.X,
            Keys.Down => Sprite.X,
            Keys.Left => Sprite.X - speed * gameTime.ElapsedGameTime.Seconds,
            Keys.Right => Sprite.X + speed * gameTime.ElapsedGameTime.Seconds,
            _ => Sprite.X
        };
        Sprite.Y = lastSegment.Direction switch 
        {
            Keys.Up => Sprite.Y - speed * gameTime.ElapsedGameTime.Seconds,
            Keys.Down => Sprite.Y + speed * gameTime.ElapsedGameTime.Seconds,
            Keys.Left => Sprite.Y,
            Keys.Right => Sprite.Y,
            _ => Sprite.Y
        };
        if (Sprite.X % 100 != 0 && Sprite.Y % 100 != 0) return;
        Location = new Point((int)Sprite.X / 100, (int)Sprite.Y / 100);
        //TODO: 处理转向贴图和进食逻辑
    }

    public void UpdateDirection(Segment lastSegment)
    {
        (int,int) diff = ((int)(lastSegment.Location.X - Location.X), (int)(lastSegment.Location.Y - Location.Y));
        Keys targetDirection = diff switch
        {
            (0, 1) => Keys.Down,
            (0, -1) => Keys.Up,
            (1, 0) => Keys.Right,
            (-1, 0) => Keys.Left,
            _ => throw new Exception("Segment位置异常，无法计算方向")
        };
        //TODO; 处理转向贴图
    }
}